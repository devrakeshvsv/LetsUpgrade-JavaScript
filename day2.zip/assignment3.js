console.log(
	`${
		Number(prompt('Enter your age...')) >= 21 ? 'Can drink' : 'Cannot drink'
	}`
);

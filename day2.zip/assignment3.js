setInterval(date, 1000);
function date() {
	var date = new Date();

	document.getElementById('date').innerHTML = `Formatted Date is : ${
		date.getMonth() < 9 ? '0' : ''
	}${date.getMonth() + 1}-${
		date.getDate() < 10 ? '0' : ''
	}${date.getDate()}-${date.getFullYear()}, ${
		date.getMonth() < 9 ? '0' : ''
	}${date.getMonth() + 1}/${
		date.getDate() < 10 ? '0' : ''
	}${date.getDate()}/${date.getFullYear()} or ${
		date.getDate() < 10 ? '0' : ''
	}${date.getDate()}-${date.getMonth() < 9 ? '0' : ''}${
		date.getMonth() + 1
	}-${date.getFullYear()}, ${
		date.getDate() < 10 ? '0' : ''
	}${date.getDate()}/${date.getMonth() < 9 ? '0' : ''}${
		date.getMonth() + 1
	}/${date.getFullYear()}`;
}

console.log(
	`Text is inputted : %c${prompt('Enter something to console it...')}`,
	'color:red'
);

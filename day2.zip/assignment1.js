setInterval(dateTime, 1000);
function dateTime() {
	var date = new Date();
	var day = '';
	var time = '';
	switch (date.getDay()) {
		case 0: {
			day = 'Sunday';
			break;
		}
		case 1: {
			day = 'Monday';
			break;
		}
		case 2: {
			day = 'Tuesday';
			break;
		}
		case 3: {
			day = 'Wednesday';
			break;
		}
		case 4: {
			day = 'Thursday';
			break;
		}
		case 5: {
			day = 'Friday';
			break;
		}
		case 6: {
			day = 'Saturday';
			break;
		}
	}

	document.getElementById(
		'dateTime'
	).innerHTML = `Today is : ${day}<br>Current time is : ${
		date.getHours() < 10 ? '0' : ''
	}${date.getHours()} ${date.getHours() <= 11 ? 'AM' : 'PM'} : ${
		date.getMinutes() < 10 ? '0' : ''
	}${date.getMinutes()} : ${
		date.getSeconds() < 10 ? '0' : ''
	}${date.getSeconds()}`;
}

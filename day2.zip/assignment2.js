window.print();

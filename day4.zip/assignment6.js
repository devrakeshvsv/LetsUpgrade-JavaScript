var number;
do {
	number = prompt('Enter a number greater than 100', 0);
} while (number < 100 && number);
